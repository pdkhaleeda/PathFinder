//
//  Signup.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 29/12/2023.
//

import SwiftUI
import Firebase
import FirebaseAuth

struct SignUp: View {
    @Binding var showSignup: Bool
    
    @State private var emailID: String = ""
    @State private var fullName: String = ""
    @State private var password: String = ""
    @State private var registrationSuccessful = false
    @State private var isLoggedIn: Bool = false
    
    
    var body: some View {
        if registrationSuccessful {
            Login(showSignup: $showSignup)
        }else{
            content
        }
    }
    var content : some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 15, content: {
                /// Back Button
                Button(action: {
                    showSignup = false
                }, label: {
                    Image(systemName:  "arrow.left")
                        .font(.title2)
                        .foregroundStyle(.gray)
                })
                .padding(.top, 10)
                
                Text("SignUp")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    .padding(.top, 25)
                
                Text("Please sign up to continue")
                    .font(.callout)
                    .fontWeight(.semibold)
                    .foregroundStyle(.gray)
                    .padding(.top, -5)
                
                VStack(spacing: 25) {
                    ///Custom Text Fields
                    CustomTF(sfIcon: "at", hint: "Email ID", value: $emailID)
                    
                    CustomTF(sfIcon: "person", hint: "Full Name", value: $fullName)
                        .padding(.top, 5)
                    
                    CustomTF(sfIcon: "lock", hint: "Password", isPassword: true, value: $password)
                        .padding(.top, 5)
                    
                    /// SignUp Button
                    GradientButton(title: "Continue", icon: "arrow.right") {
                        ///YOUR CODE
                        reg()
                        
                    }
                    .hSpacing(.trailing)
                    /// Disabling Until the Data is Entered
                    .disableWithOpacity(emailID.isEmpty || password.isEmpty || fullName.isEmpty)
                }
                .padding(.top, 20)
                
                Spacer(minLength: 0)
                
                HStack(spacing: 6) {
                    Text("Already have an account?")
                        .foregroundStyle(.gray)
                    
                    Button("Login") {
                        showSignup = false
                    }
                    
                    .fontWeight(.bold)
                    .tint(Color.purple)
                }
                .font(.callout)
                .hSpacing()
                
            })
            .padding(.vertical, 15)
            .padding(.horizontal, 25)
            .toolbar(.hidden, for: .navigationBar)
        }
        
    }
    
    func reg() {
            Auth.auth().createUser(withEmail: emailID, password: password) {result, error in
                if error != nil {
                    print(error!.localizedDescription)
                } else {
                    registrationSuccessful = true
                }
            }
        }
}
    
#Preview {
    MainLogin()
}
