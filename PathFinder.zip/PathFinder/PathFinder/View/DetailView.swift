import SwiftUI

struct DetailView: View {
    var job: ListItem = jobs[0]
    @State var showPopup = false
    @Environment(\.presentationMode) var presentationMode // Access presentation mode
    
    
    var body: some View {
        VStack {
            
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss() // Dismiss the current view
                }) {
                    Image(systemName: "arrow.left")
                        .font(.title2)
                        .foregroundColor(.gray)
                }
                .padding(.top, 10)
                
                Spacer()
            }
            
            Image("gong 1")
                .resizable()
                .frame(width: 300, height: 450)
            
            NavigationLink(destination: PopupView()) {
                Text("Edit")
                    .fontWeight(.bold)
                    .foregroundStyle(.white)
                    .padding(.vertical, 12)
                    .padding(.horizontal, 35)
                    .background(
                        .linearGradient(colors: [.purple, .indigo], startPoint: .top, endPoint: .bottom),
                        in: .capsule
                    )
            }
            .sheet(isPresented: $showPopup, content: {
                PopupView()
            })
            
            Spacer()
        }
        .padding() // Add padding around the VStack
        .navigationBarHidden(true)
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(job: jobs[0])
    }
}


