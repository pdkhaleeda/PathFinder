//
//  Homepage.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 30/12/2023.
//

import SwiftUI

struct Homepage: View {
    @State private var searchText = ""
    @State private var isSearching = false
    @State var showSignup:Bool = false
    @State private var navigateToProfile = false
    
    private let images1 = ["gong 1", "gong 1", "gong 1", "gong 1"]
    private let images2 = ["calligraphy 1", "lionDance 1", "moonCake 1", "tanglung 1"]
    
    var body: some View {
        NavigationView {
            ZStack{
                
                    VStack {
                        Rectangle()
                            .fill(.linearGradient(colors: [.purple, .indigo], startPoint: .top, endPoint: .bottom)).ignoresSafeArea()
                            .frame(height: 90)
                        Spacer()
                    }
        
                VStack{
                    
                        HStack{
                            
                            Text("PathFinder")
                                .foregroundColor(.white)
                                .font(Font.custom("Baskerville-Bold", size: 40))
                                .padding(.leading, 30)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            
                            Spacer().frame(width: 70)
                            
                            Button {
                                navigateToProfile = true
                            } label: {
                                Image(systemName: "person.circle")
                                    .resizable()
                                    .frame(width: 40, height: 40)
                                    .foregroundColor(.white)
                                    .font(.system(size: 40))
                               
                                
                            }
                            .padding(.leading, -60)
                            Spacer()
                                .fullScreenCover(isPresented: $navigateToProfile){
                                    MyProfile()
                                }
                            
                            
                            
                    }
                   
                    Divider()
                        .opacity(0)
                    ScrollView(.vertical, showsIndicators: true){
                        
                        HStack{
                            
                            Image("Ads")
                               .resizable()
                               .frame(width: 400, height: 200)
                           
                        }
                        Text("You might want to try..")
                            .font(.system(size: 20)).bold()
                            .padding(10)
                            .padding(.leading, -145)
                        
                        Spacer().frame(height: 30)
                        
                        ImageSlider(images: images1, captions: ["Resume 1", "Resume 2", "Resume 3", "Resume 4"])
                            .frame(height: 150)
                            .font(.body)
                            .padding()
                        
                        
                        Text("Recent Resume")
                            .font(.system(size: 20)).bold()
                            .padding(10)
                            .padding(.leading, -185)
                        
                        Spacer().frame(height:30)
                        
                        ImageSlider(images: images1, captions: ["Resume 1", "Resume 2", "Resume 3", "Resume 4"])
                            .frame(height: 150)
                            .font(.body)
                            .padding()
                        
                        Text("Recent Resume")
                            .font(.system(size: 20)).bold()
                            .padding(10)
                            .padding(.leading, -185)
                        
                        Spacer().frame(height:30)
                        
                        ImageSlider(images: images1, captions: ["Resume 1", "Resume 2", "Resume 3", "Resume 4"])
                            .frame(height: 150)
                            .font(.body)
                            .padding()
                        
                        Text("Recent Resume")
                            .font(.system(size: 20)).bold()
                            .padding(10)
                            .padding(.leading, -185)
                        
                        Spacer().frame(height:30)
                        
                        ImageSlider(images: images1, captions: ["Resume 1", "Resume 2", "Resume 3", "Resume 4"])
                            .frame(height: 150)
                            .font(.body)
                            .padding()
                    }
                }
                .padding(.top, 20)
            }
            .refreshable {
            
            }
        }
        .navigationBarHidden(true)
    }
    
    struct ImageSlider: View {
        let images: [String]
        let captions: [String]
        
        var body: some View {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 2) {
                    ForEach(Array(zip(images, captions)), id: \.0) { imageName, caption in
                        VStack {
                            NavigationLink(destination: destinationView(imageName: imageName)) {
                                Image(imageName)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 150, height: 150)
                                    .cornerRadius(30)
                                    .shadow(color: Color.black.opacity(0.2), radius: 5, x: 0, y: 2)
                            }
                            Text(caption) // Display caption text below
                                .font(.system(size: 15))
                                .padding(8)
                        }
                    }
                }
            }
        }
        func destinationView(imageName: String) -> some View {
            switch imageName {
            case "gong 1":
                return AnyView(DetailView())
            default:
                return AnyView(EmptyView())
            }
        }
    }
}

#Preview {
    Homepage()
}
