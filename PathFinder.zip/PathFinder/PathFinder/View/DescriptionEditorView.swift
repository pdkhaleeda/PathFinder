//
//  DescriptionEditorView.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 30/12/2023.
//

import SwiftUI

struct DescriptionEditorView: View {
    @Binding var description: String // Binding to the original description text
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        VStack {
            Text("Edit Description")
                .font(.headline)
            
            TextEditor(text: $description)
                .frame(minHeight: 50) // Set a minimum height for the text editor
                .foregroundColor(.primary) // Set text color
                .padding(8) // Add padding for a cleaner look
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.gray, lineWidth: 1) // Add a border
                )
                .cornerRadius(8) // Round the corners
            // Save button to update the description
            SaveButton(title: "Save", icon: "") {
                presentationMode.wrappedValue.dismiss()
            }            .padding()
        }
        .padding()
    }
}


struct DescriptionEditorView_Previews: PreviewProvider {
    static var previews: some View {
        let initialDescription = "Initial Description" // Provide an initial value for the description
        
        return DescriptionEditorView(description: .constant(initialDescription))
    }
}
