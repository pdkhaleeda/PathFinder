//
//  ResumePartView.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 30/12/2023.
//

import SwiftUI

struct ResumePartView: View {
    let resumePart: String // Placeholder for different resume parts
    @Binding var isPresented: Bool // Binding to control dismissal of the PopupView
    
    var body: some View {
        // You can replace this with your specific view for each resume part
        Text("Resume Part: \(resumePart)")
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        isPresented = false
                    }) {
                        Image(systemName: "arrow.left")
                    }
                }
            }
    }
}

struct ResumePartView_Previews: PreviewProvider {
    static var previews: some View {
        ResumePartView(resumePart: "Sample Resume Part", isPresented: .constant(true))
    }
}
