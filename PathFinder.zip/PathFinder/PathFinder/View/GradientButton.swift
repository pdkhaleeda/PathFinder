//
//  GradientButton.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 29/12/2023.
//

import SwiftUI

struct GradientButton: View {
    var title: String
    var icon: String
    var onClick: () -> ()
    var body: some View {
        Button(action: onClick, label: {
            HStack(spacing: 15) {
                Text(title)
                Image(systemName: icon)
            }
            .fontWeight(.bold)
            .foregroundStyle(.white)
            .padding(.vertical, 12)
            .padding(.horizontal, 35)
            .background(.linearGradient(colors: [.purple, .indigo], startPoint: .top, endPoint: .bottom), in: .capsule)
        })
    }
}

struct LogoutButton: View {
    var title: String
    var icon: String
    var onClick: () -> ()
    var body: some View {
        Button(action: onClick, label: {
            HStack(spacing: 10) {
                Text(title)
                    .font(.headline)
                Image(systemName: icon)
                    .font(.headline)
            }
            .fontWeight(.bold)
            .foregroundStyle(.white)
            .padding(.vertical, 10)
            .padding(.horizontal, 20)
            .background(.linearGradient(colors: [.red, .pink], startPoint: .top, endPoint: .bottom), in: .capsule)
        })
    }
}

struct SaveButton: View {
    var title: String
    var icon: String
    var onClick: () -> ()
    var body: some View {
        Button(action: onClick, label: {
            HStack(spacing: 10) {
                Text(title)
                    .font(.headline)
            }
            .fontWeight(.bold)
            .foregroundStyle(.white)
            .padding(.vertical, 10)
            .padding(.horizontal, 20)
            .background(.linearGradient(colors: [.purple, .indigo], startPoint: .top, endPoint: .bottom), in: .capsule)
        })
    }
}
#Preview {
    MainLogin()
}
