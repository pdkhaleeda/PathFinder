//
//  EditAccount.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 31/12/2023.
//

import SwiftUI

struct EditAccount: View {
    var body: some View {
        Text("Edit Account")
    }
}

#Preview {
    EditAccount()
}
