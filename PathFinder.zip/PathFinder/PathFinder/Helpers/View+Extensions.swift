//
//  View+Extensions.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 28/12/2023.
//

import SwiftUI

// Extensions.swift or UIColor+Extensions.swift

import UIKit

extension UIColor {
    static let appOrange = UIColor.orange // Replace UIColor.yellow with your desired yellow color
}

extension Color {
    static let appOrange = Color.orange // Define your desired shade of orange here
}

extension View {
    ///View Alignment
    @ViewBuilder
    func hSpacing(_ alignment: Alignment = .center) -> some View {
        self
            .frame(maxWidth: .infinity, alignment: alignment)
    }
    
    @ViewBuilder
    func vSpacing(_ alignment: Alignment = .center) -> some View {
        self
            .frame(maxHeight: .infinity, alignment: alignment)
    }
    
    @ViewBuilder
    func disableWithOpacity(_ condition: Bool) -> some View {
        self
            .disabled(condition)
            .opacity(condition ? 0.5 : 1)
    }
}
