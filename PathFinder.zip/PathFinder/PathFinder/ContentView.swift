import SwiftUI

struct ContentView: View {
    
    var body: some View {
        
            
        
        ZStack {
            TabView {
                
                Homepage()
                    .tabItem {
                        Label("Home", systemImage: "house")
                    }
                JobCategory()
                    .tabItem {
                        Label("Category", systemImage: "list.bullet.below.rectangle")
                    }
                MyResume()
                    .tabItem {
                        Label("My Resume", systemImage: "doc.text.image")
                    }
                
            }.toolbarBackground(.white, for: .tabBar)
                .toolbarBackground(.visible, for: .tabBar)
            
        }
                            
    }
    
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
