//
//  ContentView.swift
//  listsAndNavDemo
//
//  Created by Puteri Damia Khaleeda
//

import SwiftUI

struct JobCategory: View {
    @State private var searchText = ""
    @State private var isSearching = false
    
    var filteredJobs: [ListItem] {
        if searchText.isEmpty {
            return jobs
        } else {
            return jobs.filter { $0.title.lowercased().contains(searchText.lowercased()) }
        }
    }
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading, spacing: 5) { // Align the VStack content to the leading edge
                // Header titled "Category" on the left side
                Text("Category")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding(.top, 20)
                    .padding(.leading, 30) // Add padding to adjust the position
                
                SearchBar(text: $searchText, isSearching: $isSearching)
                    .padding(.top, 10)
                
                List(filteredJobs) { job in
                    NavigationLink(destination: DetailView(job: job)) {
                        HStack {
                            VStack(alignment: .leading) {
                                Text("\(job.title)")
                                    .font(.system(size: 18, weight: .bold))
                            }
                            Spacer()
                            
                            Image(job.image)
                                .resizable()
                                .frame(width: 100, height: 100)
                                .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                        }
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
        }
    }
}

struct SearchBar: View {
    @Binding var text: String
    @Binding var isSearching: Bool
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
                .padding(.leading, 8)
            
            TextField("Search Category...", text: $text)
                .padding(.leading, 8)
            
            Button(action: {
                text = ""
                isSearching = false
                UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
            }) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(.gray)
            }
            .padding(.trailing, 8)
        }
        .padding()
        .background(Color(.systemGray5))
        .clipShape(Capsule())
        .padding(.horizontal)
    }
}


// Your ListItem struct and animals array remain the same


struct JobCategory_Previews: PreviewProvider {
    static var previews: some View {
        JobCategory()
    }
}

struct ListItem: Identifiable {
    var id = UUID().uuidString
    var title: String
    var image: String
}

var jobs = [
    ListItem(title: "Computer Scientist", image: "dolphins"),
    ListItem(title: "Human Resource", image: "monkeys"),
    ListItem(title: "Graphic Designer", image: "turtle"),
    ListItem(title: "Civil Engineer", image: "goat"),
    ListItem(title: "Web Developer", image: "mouse"),
    
]
