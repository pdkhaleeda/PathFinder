//
//  MyProfile.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 31/12/2023.
//

import SwiftUI


struct MyProfile: View {
    @Environment(\.presentationMode) var presentationMode // Access presentation mode
    @State private var navigateToLogin = false
    var body: some View {
        NavigationStack {
            ZStack{
                
                VStack{
                    Rectangle()
                        .fill(.linearGradient(colors: [.purple, .indigo], startPoint: .top, endPoint: .bottom)).ignoresSafeArea()
                        .frame(height: 300)
                    Spacer()
                }
                VStack {
                    
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // Dismiss the current view
                        }) {
                            Image(systemName: "arrow.left")
                                .font(.title2)
                                .foregroundColor(.white)
                        }
                        .padding(.leading)
                        
                        Spacer()
                        
                        
                        
                    }
                    Spacer()
                    
                    
                    VStack(spacing: 15){
                        Spacer()
                            .frame(height: 1)
                        
                        Image("damia")
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 100, height: 100)
                            .clipShape(Circle())
                        
                        Text("Puteri Damia Khaleeda")
                            .font(.system(size: 25))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.top ,10)
                        
                        Spacer()
                        
                       
                        ProfileList()
                      
                        } 
                
                        .padding(.top, -30)
                    }
                .padding(.top, 20)
                   
                }
            }
        
        }
    }
    #Preview {
        MyProfile()
    }
