import SwiftUI

struct PopupView: View {
    @Environment(\.presentationMode) var presentationMode // Access presentation mode
    @State private var selectedPart: String? = nil // Track selected part
    @State private var isResumePartViewPresented = false // Control whether ResumePartView is presented
    @State private var editedDescription = "New Description" // Store the edited description
    @State private var isEditingDescription = false // Control whether to present the editing view
    
    var body: some View {
        NavigationView {
            ScrollView{
                VStack {
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss() // Dismiss the current view
                        }) {
                            Image(systemName: "arrow.left")
                                .font(.title2)
                                .foregroundColor(.gray)
                        }
                        .padding(.top, 25)
                        
                        Spacer()
                    }
                    .padding(.horizontal) // Add horizontal padding to the HStack
                    
                    Spacer() // Add a spacer to push content below the back button
                    
                    VStack(spacing: 20) {
                        Text("Summary")
                            .font(.system(size: 22))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, -10)
                        
                        
                        Button(action: {
                            isEditingDescription = true // Show description editor
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.white)
                                    .frame(height: 100)
                                    . overlay(Rectangle().stroke(Color.black, lineWidth: 1)) // Border overlay
                                
                                Text(editedDescription) // Display edited description
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.horizontal) // Adjust horizontal padding
                            }
                        }
                        Spacer()
                        
                        
                        Text("Education")
                            .font(.system(size: 22))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, -10)
                        
                        
                        Button(action: {
                            isEditingDescription = true // Show description editor
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.white)
                                    .frame(height: 100)
                                    . overlay(Rectangle().stroke(Color.black, lineWidth: 1)) // Border overlay
                                
                                Text(editedDescription) // Display edited description
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.horizontal) // Adjust horizontal padding
                            }
                        }
                        Spacer()
                        
                        Text("Work Experience")
                            .font(.system(size: 22))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, -10)
                        
                        
                        Button(action: {
                            isEditingDescription = true // Show description editor
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.white)
                                    .frame(height: 100)
                                    . overlay(Rectangle().stroke(Color.black, lineWidth: 1)) // Border overlay
                                
                                Text(editedDescription) // Display edited description
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.horizontal) // Adjust horizontal padding
                            }
                        }
                        Spacer()
                        
                        Text("Skills")
                            .font(.system(size: 22))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, -10)
                        
                        
                        Button(action: {
                            isEditingDescription = true // Show description editor
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.white)
                                    .frame(height: 100)
                                    . overlay(Rectangle().stroke(Color.black, lineWidth: 1)) // Border overlay
                                
                                Text(editedDescription) // Display edited description
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.horizontal) // Adjust horizontal padding
                            }
                        }
                        Spacer()
                        
                        Text("Languages")
                            .font(.system(size: 22))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.bottom, -10)
                        
                        
                        Button(action: {
                            isEditingDescription = true // Show description editor
                        }) {
                            ZStack {
                                Rectangle()
                                    .foregroundColor(.white)
                                    .frame(height: 100)
                                    . overlay(Rectangle().stroke(Color.black, lineWidth: 1)) // Border overlay
                                
                                Text(editedDescription) // Display edited description
                                    .font(.headline)
                                    .foregroundColor(.black)
                                    .padding(.horizontal) // Adjust horizontal padding
                            }
                        }
                        Spacer()
                            .padding()
                    }
                    .padding(.horizontal, 40)
                    .padding(.top, 40)
                    .sheet(isPresented: $isResumePartViewPresented, content: {
                        if let part = selectedPart {
                            ResumePartView(resumePart: part, isPresented: $isResumePartViewPresented)
                        }
                    })
                    
                }
            }
            .sheet(isPresented: $isEditingDescription) {
                DescriptionEditorView(description: $editedDescription)
            }
            .navigationBarHidden(true)
        }
        .navigationBarHidden(true)
    }
}



struct PopupView_Previews: PreviewProvider {
    static var previews: some View {
        PopupView()
    }
}
