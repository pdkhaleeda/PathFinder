//
//  MyResume.swift
//  PathFinder
//
//  Created by Puteri Damia Khaleeda on 30/12/2023.
//

import SwiftUI

struct MyResume: View {
    var body: some View {
     Text("My Resume")
    }
}

#Preview {
    MyResume()
}
