import SwiftUI

struct ProfileList: View {
    
    struct ListItem: Identifiable {
        var id = UUID()
        var systemImageName: String
        var text: String
    }
    
    let items: [ListItem] = [
        ListItem(systemImageName: "person.circle", text: "Your Account"),
        ListItem(systemImageName: "house", text: "Home"),
        ListItem(systemImageName: "rectangle.grid.1x2", text: "Category"),
        ListItem(systemImageName: "doc.text", text: "My Resume"),
        ListItem(systemImageName: "trash", text: "Deleted Resume"),
        ListItem(systemImageName: "arrow.uturn.backward.circle", text: "Logout"),
        // Add more items as needed
    ]
    
    @State private var showLogoutAlert = false
    @State private var shouldNavigateToLogin = false
    
    var body: some View {
        NavigationView {
            List {
                ForEach(items) { item in
                    if item.text == "Logout" {
                        Button(action: {
                            showLogoutAlert.toggle()
                        }) {
                            HStack {
                                Image(systemName: item.systemImageName)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 30, height: 40)
                                    .foregroundColor(Color.purple.opacity(0.8))
                                
                                Text(item.text)
                                    .font(.system(size: 20))
                                    .foregroundColor(item.text == "Logout" ? Color.red : Color.primary)
                                    .padding(.leading, 10)
                            }
                        }
                    } else {
                        NavigationLink(
                            destination: destinationForListItem(item),
                            label: {
                                HStack {
                                    Image(systemName: item.systemImageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(width: 30, height: 40)
                                        .foregroundColor(Color.purple.opacity(0.8))
                                    
                                    Text(item.text)
                                        .font(.system(size: 20))
                                        .foregroundColor(item.text == "Logout" ? Color.red : Color.primary)
                                        .padding(.leading, 10)
                                }
                            })
                    }
                }
            }
            .listStyle(PlainListStyle())
            .alert(isPresented: $showLogoutAlert) {
                Alert(
                    title: Text("Logout"),
                    message: Text("Are you sure you want to log out?"),
                    primaryButton: .destructive(Text("Yes")) {
                        do {
                            try performLogout()
                            shouldNavigateToLogin = true
        
                        } catch {
                            print(error)
                        }
                    },
                    secondaryButton: .cancel()
                )
            }
            .background(
                NavigationLink("", destination: MainLogin(), isActive: $shouldNavigateToLogin)
            )
        }
    }
    
    func destinationForListItem(_ item: ListItem) -> some View {
        switch item.text {
        case "Your Account":
            return AnyView(EditAccount()) // Replace MyProfile() with the desired destination view
        case "Home":
            return AnyView(ContentView()) // Replace Homepage() with the desired destination view
        case "Category":
            return AnyView(JobCategory()) // Replace JobCategory() with the desired destination view
        case "My Resume":
            return AnyView(MyResume()) // Replace MyResume() with the desired destination view
        case "Deleted Resume":
            return AnyView(DeletedResume()) // Replace TrashView() with the desired destination view
        default:
            return AnyView(EmptyView())
        }
    }
    
    func performLogout() throws {
        // Perform logout actions here
        try AuthenticationManager.shared.signOut()
        // For now, set shouldNavigateToLogin to true
        
    }
}

struct list1_Previews: PreviewProvider {
    static var previews: some View {
        ProfileList()
    }
}
